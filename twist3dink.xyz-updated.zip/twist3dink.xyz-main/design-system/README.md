# Design System

This folder contains the **design token source-of-truth** and a deterministic **build pipeline** that emits consumption-ready artifacts (CSS variables + TypeScript exports).

## Structure

- `tokens/`
  - `base.json` — primitives (literal values only)
  - `semantic.json` — semantic tokens (references only)
  - `context.json` — context/theme bindings (references only)
  - `aliases.json` — experimental aliases (references only; must live under `experimental.*`)
- `schemas/tokens.schema.json` — JSON Schema for the token files
- `build/build-tokens.mjs` — build + contract validation + output generation
- `outputs/` — generated artifacts

## Outputs

Builds generate:

- `outputs/tokens.css` — **consumption** CSS variables (semantic + context)
- `outputs/tokens.ts` — **consumption** TypeScript exports (semantic + context)
- `outputs/tokens.experimental.css` — experimental CSS vars (aliases only)
- `outputs/tokens.experimental.ts` — experimental TS exports (aliases only)
- `outputs/tokens.fingerprint.json` — SHA256 fingerprint for drift detection

## One-time setup

From `design-system/`:

```bash
npm install
```

## Common commands

From `design-system/`:

```bash
# Build tokens (validates schema + contracts first)
npm run tokens:build

# Clean generated outputs
npm run tokens:clean

# Build + verify expected artifacts exist
npm run tokens:verify
```

## Contract rules (enforced)

`build/build-tokens.mjs` enforces additional rules beyond JSON Schema:

- Token keys: lowercase `a-z0-9` only (no spaces, underscores, camelCase).
- `base.json` values must be **literals** (no `{ref}` values).
- `semantic.json`, `context.json`, `aliases.json` values must be **references only** (`{path.to.token}`).
- `aliases.json` must have a single top-level key: `experimental`.
