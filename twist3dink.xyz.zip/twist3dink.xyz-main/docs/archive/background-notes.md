# Background Notes

This document will house miscellaneous background notes and supporting information.
