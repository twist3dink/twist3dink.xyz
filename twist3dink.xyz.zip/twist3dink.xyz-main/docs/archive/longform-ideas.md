# Longform Ideas

This document will archive longer-form writing ideas and outlines.
